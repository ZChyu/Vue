<template>
  <div class="deit">
    <div class="crumbs">
      <el-breadcrumb separator="/">
            <el-breadcrumb-item><i class="el-icon-date"></i> 数据管理</el-breadcrumb-item>
            <el-breadcrumb-item>食品列表</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="cantainer">
        </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'foodlist',
  data () {
      return {
      }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
